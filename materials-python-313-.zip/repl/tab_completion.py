import math

print(math.cos(2 * math.pi))

headline = "python 3.13"
print(headline.title())
print(headline.title().center(20))
print(headline.title().center(20, "-"))
