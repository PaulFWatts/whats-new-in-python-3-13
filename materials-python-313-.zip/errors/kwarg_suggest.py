numbers = [2, 0, 2, 4, 1, 0, 0, 1]

# print(sorted(numbers, reversed=True))
print(sorted(numbers, reverse=True))
