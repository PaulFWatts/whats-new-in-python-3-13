def inverse(number):
    return 1 / number


print(inverse(0))
